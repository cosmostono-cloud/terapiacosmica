"use client";

import { MadeWithDyad } from "@/components/made-with-dyad";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import HowItWorksCard from "@/components/HowItWorksCard";
import BenefitCard from "@/components/BenefitCard";
import WhatYouReceiveCard from "@/components/WhatYouReceiveCard";
import TestimonialCard from "@/components/TestimonialCard";
import PriceCard from "@/components/PriceCard";
import FAQItem from "@/components/FAQItem";
import { Accordion } from "@/components/ui/accordion";

import {
  Heart, Brain, Target, RefreshCw, Shield, Zap, ArrowDown,
  FileText, Headphones, Book, Calendar, MessageCircle, // Icons for WhatYouReceiveCard
} from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />

      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center py-20 px-4 md:px-8 lg:px-16 text-center min-h-[calc(100vh-80px)]"> {/* Adjusted min-h to account for header */}
        {/* Background image placeholder */}
        <div className="absolute inset-0 z-0">
          {/* Substitua '/placeholder.svg' pela sua imagem de fundo de alta qualidade para um visual premium.
              Exemplo: Se sua imagem estiver em 'public/images/hero-bg.jpg', use 'src="/images/hero-bg.jpg"' */}
          <img
            src="/placeholder.svg"
            alt="Background Cósmico"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div> {/* Dark overlay */}
        </div>

        <div className="relative z-10 space-y-6 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight">
            Terapia Cósmica: <span className="text-primary">4 semanas</span> para reprogramar padrões e liberar bloqueios internos
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Método exclusivo + suporte no WhatsApp por 30 dias
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mt-8">
            <Button
              size="lg"
              className="bg-gradient-to-r from-golden-start to-golden-end text-background hover:from-golden-end hover:to-golden-start text-lg px-8 py-6 rounded-full shadow-xl transition-all duration-300 ease-in-out transform hover:scale-105"
            >
              Falar no WhatsApp agora
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-secondary text-foreground border-secondary hover:bg-primary/20 hover:text-primary text-lg px-8 py-6 rounded-full shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 flex items-center"
            >
              Como funciona <ArrowDown className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </section>

      {/* What You Receive Section */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-background">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            O que você <span className="text-primary">recebe</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Um pacote completo para sua transformação
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <WhatYouReceiveCard
              icon={FileText}
              title="4 Sessões de Terapia"
              description="Uma por semana, 50-70 minutos cada, por videochamada com o Boss"
            />
            <WhatYouReceiveCard
              icon={Headphones}
              title="Áudios de Apoio"
              description="Scripts guiados para praticar em casa e reforçar as mudanças"
            />
            <WhatYouReceiveCard
              icon={Book}
              title="Exercícios Práticos"
              description="Atividades personalizadas para integrar o aprendizado no dia a dia"
            />
            <WhatYouReceiveCard
              icon={Calendar}
              title="Plano de 30 Dias"
              description="Roteiro estruturado para consolidar sua transformação"
            />
            <WhatYouReceiveCard
              icon={MessageCircle}
              title="Suporte no WhatsApp"
              description="Acompanhamento direto para tirar dúvidas e manter o foco"
            />
          </div>
        </div>
      </section>

      {/* How it works Section (Existing) */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-secondary">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Como funciona a <span className="text-primary">Terapia Cósmica</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Um processo estruturado de transformação em 4 semanas
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <HowItWorksCard
              step={1}
              title="Mapeamento e Objetivos"
              description="Identificamos suas crenças limitantes e traçamos objetivos claros para a jornada."
              time="50-70 min"
            />
            <HowItWorksCard
              step={2}
              title="Reprogramação Profunda"
              description="Aplicamos técnicas de PNL e hipnose para ressignificar padrões e traumas."
              time="50-70 min"
            />
            <HowItWorksCard
              step={3}
              title="Integração e Prática"
              description="Consolidamos as mudanças com exercícios práticos e scripts de apoio."
              time="50-70 min"
            />
            <HowItWorksCard
              step={4}
              title="Autonomia e Crescimento"
              description="Finalizamos com ferramentas para manter sua evolução contínua."
              time="50-70 min"
            />
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-background">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Quem já <span className="text-primary">experimentou</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Histórias reais de transformação
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <TestimonialCard
              imageSrc="/placeholder.svg" // Replace with actual image
              name="Mariana C."
              title="Empresária"
              rating={5}
              testimonial="A Terapia Cósmica me ajudou a identificar e romper com padrões de autossabotagem que carregava há anos. Em 4 semanas, consegui clareza e ferramentas práticas que uso até hoje. O suporte no WhatsApp foi essencial nos momentos difíceis."
            />
            <TestimonialCard
              imageSrc="/placeholder.svg" // Replace with actual image
              name="Roberto S."
              title="Consultor"
              rating={5}
              testimonial="Estava preso em ciclos de procrastinação e falta de foco. O método combinou técnicas que realmente funcionaram pra mim. Hoje tenho mais disciplina, objetivos claros e uma confiança que não tinha antes. Recomendo pra quem quer mudanças reais."
            />
          </div>
        </div>
      </section>

      {/* Benefits Section (Existing) */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-secondary">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12">
            Benefícios da Terapia Cósmica
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <BenefitCard
              icon={Heart}
              title="Alívio Emocional"
              description="Reduza ansiedade, estresse e padrões emocionais que drenam sua energia."
            />
            <BenefitCard
              icon={Brain}
              title="Clareza Mental"
              description="Entenda seus bloqueios e ganhe perspectiva sobre suas escolhas."
            />
            <BenefitCard
              icon={Target}
              title="Foco e Direção"
              description="Defina objetivos claros e alinhe suas ações com seus valores."
            />
            <BenefitCard
              icon={RefreshCw}
              title="Novos Hábitos"
              description="Crie rotinas saudáveis que sustentam seu crescimento a longo prazo."
            />
            <BenefitCard
              icon={Shield}
              title="Confiança Genuína"
              description="Desenvolva autoestima baseada em seu poder interior e autenticidade."
            />
            <BenefitCard
              icon={Zap}
              title="Disciplina Interna"
              description="Fortaleça sua capacidade de agir mesmo quando a motivação falha."
            />
          </div>
        </div>
      </section>

      {/* Investment Section */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-background">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Investimento na sua <span className="text-primary">transformação</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Um passo decisivo para a sua evolução
          </p>
          <PriceCard />
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 md:px-8 lg:px-16 bg-secondary">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Perguntas <span className="text-primary">frequentes</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Tire suas dúvidas antes de começar
          </p>
          <Accordion type="single" collapsible className="w-full max-w-3xl mx-auto">
            <FAQItem
              value="item-1"
              question="Como funciona o atendimento online?"
              answer="As sessões são realizadas por videochamada (Google Meet, Zoom, etc.), permitindo que você participe de qualquer lugar com conforto e privacidade."
            />
            <FAQItem
              value="item-2"
              question="Quanto tempo dura cada sessão?"
              answer="Cada sessão tem duração de 50 a 70 minutos, dependendo da necessidade e do fluxo do processo."
            />
            <FAQItem
              value="item-3"
              question="Preciso ter algum conhecimento prévio?"
              answer="Não é necessário nenhum conhecimento prévio. O método é guiado e adaptado para todos os níveis de experiência."
            />
            <FAQItem
              value="item-4"
              question="A Terapia Cósmica substitui tratamento médico ou psicológico?"
              answer="Não. A Terapia Cósmica é um complemento e não substitui tratamentos médicos ou psicológicos. É importante sempre seguir as orientações de profissionais de saúde."
            />
            <FAQItem
              value="item-5"
              question="Como funciona a garantia de 7 dias?"
              answer="Você tem 7 dias após a primeira sessão para experimentar o método. Se não estiver satisfeito, garantimos o reembolso total do seu investimento."
            />
            <FAQItem
              value="item-6"
              question="Posso parcelar o pagamento?"
              answer="Sim, o pagamento pode ser parcelado em até 12 vezes no cartão de crédito."
            />
            <FAQItem
              value="item-7"
              question="Quanto tempo tenho acesso ao suporte no WhatsApp?"
              answer="Você terá suporte direto no WhatsApp por 30 dias, a partir da data da primeira sessão."
            />
            <FAQItem
              value="item-8"
              question="Vou receber algum material de apoio?"
              answer="Sim, você receberá áudios guiados e scripts de apoio para praticar entre as sessões e consolidar seu aprendizado."
            />
            <FAQItem
              value="item-9"
              question="Preciso fazer as 4 sessões seguidas, uma por semana?"
              answer="Recomendamos seguir o ritmo de uma sessão por semana para otimizar os resultados, mas podemos ajustar conforme sua disponibilidade."
            />
            <FAQItem
              value="item-10"
              question="Resultados são garantidos?"
              answer="Os resultados dependem do seu comprometimento e aplicação das técnicas. Nosso método é comprovado, mas a transformação é uma jornada pessoal."
            />
          </Accordion>
        </div>
      </section>

      <MadeWithDyad />
    </div>
  );
};

export default Index;