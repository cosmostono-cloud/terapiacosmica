"use client";

import React from 'react';
import { Button, ButtonProps } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface GlowingButtonProps extends ButtonProps {
  children: React.ReactNode;
  alwaysGlow?: boolean; // New prop to control continuous glow
}

const GlowingButton: React.FC<GlowingButtonProps> = ({ children, className, alwaysGlow = false, ...props }) => {
  return (
    <div className="relative group inline-flex overflow-hidden rounded-full"> {/* Added overflow-hidden and rounded-full here */}
      <Button
        className={cn(
          "relative z-10",
          "bg-gradient-to-r from-golden-start to-golden-end text-background hover:from-golden-end hover:to-golden-start",
          "shadow-xl transition-all duration-300 ease-in-out transform hover:scale-105",
          className
        )}
        {...props}
      >
        {children}
      </Button>
      {/* Pulse glow effect */}
      <span
        className={cn(
          "absolute inset-0 rounded-full",
          "bg-primary/50 blur-md", // Golden translucent glow
          alwaysGlow ? "opacity-100 animate-pulse-glow" : "opacity-0 group-hover:opacity-100 group-hover:animate-pulse-glow",
          "transition-opacity duration-300",
          "pointer-events-none z-0"
        )}
      />
      {/* Sweeping shine effect */}
      <span
        className={cn(
          "absolute inset-0 z-20", // Ensure shine is above pulse glow but below button text
          "bg-gradient-to-r from-transparent via-white/50 to-transparent", // White translucent shine
          "transform -skew-x-12", // Skew for a dynamic look
          "pointer-events-none",
          alwaysGlow ? "opacity-100 animate-shine" : "opacity-0 group-hover:opacity-100 group-hover:animate-shine"
        )}
        style={{ width: '50%' }} // Control the width of the shine
      />
    </div>
  );
};

export default GlowingButton;