"use client";

import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface FAQItemProps {
  question: string;
  answer: string;
  value: string; // Unique value for AccordionItem
}

const FAQItem: React.FC<FAQItemProps> = ({ question, answer, value }) => {
  return (
    <AccordionItem value={value} className="border-b border-border bg-card rounded-lg mb-4 shadow-md">
      <AccordionTrigger className="text-foreground hover:no-underline px-6 py-4 text-left text-lg font-medium">
        {question}
      </AccordionTrigger>
      <AccordionContent className="text-muted-foreground px-6 pb-4 leading-relaxed">
        {answer}
      </AccordionContent>
    </AccordionItem>
  );
};

export default FAQItem;