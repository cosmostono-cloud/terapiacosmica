"use client";

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface WhatYouReceiveCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

const WhatYouReceiveCard: React.FC<WhatYouReceiveCardProps> = ({ icon: Icon, title, description }) => {
  return (
    <Card className="p-6 bg-card border border-border rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out flex flex-col items-start text-left">
      <CardHeader className="flex flex-row items-center p-0 mb-4">
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/20 text-primary mr-4">
          <Icon className="h-6 w-6" />
        </div>
        <CardTitle className="text-xl font-semibold text-foreground">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <p className="text-muted-foreground leading-relaxed">
          {description}
        </p>
      </CardContent>
    </Card>
  );
};

export default WhatYouReceiveCard;