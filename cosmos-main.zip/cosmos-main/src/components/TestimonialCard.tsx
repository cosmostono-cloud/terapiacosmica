"use client";

import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Star } from 'lucide-react';

interface TestimonialCardProps {
  imageSrc: string;
  name: string;
  title: string;
  rating: number;
  testimonial: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ imageSrc, name, title, rating, testimonial }) => {
  return (
    <Card className="p-6 bg-card border border-border rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out">
      <CardHeader className="flex flex-col items-start p-0 mb-4">
        <div className="flex items-center mb-4">
          <img src={imageSrc} alt={name} className="h-12 w-12 rounded-full object-cover mr-4" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">{name}</h3>
            <p className="text-sm text-muted-foreground">{title}</p>
          </div>
        </div>
        <div className="flex">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`h-5 w-5 ${i < rating ? 'text-primary fill-primary' : 'text-muted-foreground'}`}
            />
          ))}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <p className="text-muted-foreground leading-relaxed italic">
          "{testimonial}"
        </p>
      </CardContent>
    </Card>
  );
};

export default TestimonialCard;