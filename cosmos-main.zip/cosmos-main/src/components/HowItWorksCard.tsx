"use client";

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Timer } from 'lucide-react';

interface HowItWorksCardProps {
  step: number;
  title: string;
  description: string;
  time: string;
}

const HowItWorksCard: React.FC<HowItWorksCardProps> = ({ step, title, description, time }) => {
  return (
    <Card className="p-6 bg-secondary border border-secondary rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 ease-in-out">
      <CardHeader className="flex flex-col items-start p-0 mb-4">
        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-background font-bold text-lg mb-4">
          {step}
        </div>
        <CardTitle className="text-2xl font-semibold text-foreground mb-2">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <p className="text-muted-foreground leading-relaxed mb-4">
          {description}
        </p>
        <div className="flex items-center text-muted-foreground text-sm">
          <Timer className="h-4 w-4 mr-2 text-primary" />
          <span>{time}</span>
        </div>
      </CardContent>
    </Card>
  );
};

export default HowItWorksCard;