"use client";

import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GlowingButton from './GlowingButton'; // Import GlowingButton

const Header = () => {
  return (
    <header className="flex items-center justify-between p-4 md:px-8 bg-background text-foreground border-b border-secondary">
      <div className="flex items-center space-x-2">
        {/* Substitua '/placeholder.svg' pela sua imagem de logo */}
        <img src="/placeholder.svg" alt="Tô no Cosmos Logo" className="h-10 w-10 rounded-full" />
        <span className="text-xl font-semibold text-primary">Tô no Cosmos</span>
      </div>
      <div className="flex items-center space-x-4">
        <a href="tel:+5511919872851" className="flex items-center text-foreground hover:text-primary transition-colors duration-200">
          <Phone className="h-4 w-4 mr-2" />
          <span className="hidden md:inline">(11) 91987-2851</span>
        </a>
        <GlowingButton // Use GlowingButton here
          asChild
          alwaysGlow={true} // Make it glow continuously
          // The className here will be passed to the <a> tag
          className="flex items-center text-base px-4 py-2 rounded-full" // Adjust classes for header button size
        >
          <a href="https://wa.me/5511919872851" target="_blank" rel="noopener noreferrer">
            <MessageCircle className="h-4 w-4 mr-2" />
            WhatsApp
          </a>
        </GlowingButton>
      </div>
    </header>
  );
};

export default Header;