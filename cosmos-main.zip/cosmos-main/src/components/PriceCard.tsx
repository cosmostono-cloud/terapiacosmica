"use client";

import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Check, CreditCard, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GlowingButton from './GlowingButton'; // Import the new component

const PriceCard = () => {
  return (
    <Card className="p-8 bg-card border border-border rounded-xl shadow-2xl max-w-lg mx-auto"> {/* Changed max-w-md to max-w-lg */}
      <CardHeader className="p-0 mb-6 text-center">
        <span className="inline-block bg-primary/20 text-primary text-sm font-medium px-3 py-1 rounded-full mb-4">
          Pacote Completo
        </span>
        <p className="text-5xl font-bold text-foreground mb-2">R$ 997</p>
        <p className="text-muted-foreground text-sm">ou 12x de R$ 99,70 no cartão</p>
      </CardHeader>
      <CardContent className="p-0 space-y-4">
        <ul className="space-y-3 mb-6">
          <li className="flex items-center text-foreground">
            <Check className="h-5 w-5 text-primary mr-3" />
            <span>4 sessões de 50-70 minutos com o Boss</span>
          </li>
          <li className="flex items-center text-foreground">
            <Check className="h-5 w-5 text-primary mr-3" />
            <span>Áudios e scripts guiados de apoio</span>
          </li>
          <li className="flex items-center text-foreground">
            <Check className="h-5 w-5 text-primary mr-3" />
            <span>Exercícios práticos personalizados</span>
          </li>
          <li className="flex items-center text-foreground">
            <Check className="h-5 w-5 text-primary mr-3" />
            <span>Plano estruturado de 30 dias</span>
          </li>
          <li className="flex items-center text-foreground">
            <Check className="h-5 w-5 text-primary mr-3" />
            <span>Suporte direto no WhatsApp por 30 dias</span>
          </li>
        </ul>

        <div className="bg-secondary p-4 rounded-lg flex items-center mb-4">
          <CreditCard className="h-5 w-5 text-primary mr-3" />
          <div>
            <p className="text-foreground font-medium">Pix ou Cartão</p>
            <p className="text-muted-foreground text-sm">Parcelamento em até 12x</p>
          </div>
        </div>

        <div className="bg-secondary p-4 rounded-lg flex items-center mb-6">
          <Lock className="h-5 w-5 text-primary mr-3" />
          <div>
            <p className="text-foreground font-medium">Pagamento Seguro</p>
            <p className="text-muted-foreground text-sm">Transação protegida e dados criptografados</p>
          </div>
        </div>

        <GlowingButton
          size="lg"
          className="w-full text-lg px-8 py-6 rounded-full mb-4"
        >
          Garantir minha vaga agora
        </GlowingButton>
        <Button
          size="lg"
          variant="outline"
          className="w-full bg-secondary text-foreground border-secondary hover:bg-primary/20 hover:text-primary text-lg px-8 py-6 rounded-full shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105"
        >
          Ver perguntas frequentes
        </Button>
      </CardContent>
    </Card>
  );
};

export default PriceCard;